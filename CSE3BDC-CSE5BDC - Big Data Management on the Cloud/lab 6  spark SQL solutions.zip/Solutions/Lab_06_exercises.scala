// Exercise 1

case class Fruit(name: String, price: Double, stock: Int)

// Exercise 2

val fridgeParquetDS = fridgeParquetDF.as[Fridge]
fridgeParquetDS.show(10)

// Exercise 3

val continentDF = spark.read.json("Input_data/TaskC/continent.json")
val namesDF = spark.read.json("Input_data/TaskC/names.json")
continentDF.
  filter($"continent" === "OC").
  select($"countryCode").
  join(namesDF, "countryCode").
  orderBy($"name".asc).
  show(10)

// Exercise 4

fridgeDF.groupBy("brand").avg("efficiency").
  orderBy($"avg(efficiency)".desc).show(5)

// Exercise 5

spark.read.json("Input_data/TaskC/continent.json").createOrReplaceTempView("continents")
spark.read.json("Input_data/TaskC/names.json").createOrReplaceTempView("names")
spark.sql("""SELECT name FROM
  continents INNER JOIN names
  ON continents.countryCode = names.countryCode
  WHERE continent = 'OC'
  ORDER BY name ASC""").show(10)

// Exercise 6

val percentageDF = fractionDF.
  withColumn("percentage", toPercentageUdf($"fraction")).
  drop("fraction")
