
library(lpSolveAPI)


lprec <- make.lp(13, 10) # 10 variables and 13 constraints

lp.control(lprec, sense= "maximize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(0.6135,0.5314,0.3545,-0.5452,0.2919,0,0,0,0,0)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,5), indices = c(1:5))
set.row(lprec, 2, c(1,-5000), indices = c(1,6))
set.row(lprec, 3, c(1,-5000), indices = c(2,7))
set.row(lprec, 4, c(1,-5000), indices = c(3,8))
set.row(lprec, 5, c(1,-5000), indices = c(4,9))
set.row(lprec, 6, c(1,-5000), indices = c(5,10))
set.row(lprec, 7, c(1,-3000), indices = c(1,6))
set.row(lprec, 8, c(1,-3000), indices = c(2,7))
set.row(lprec, 9, c(1,-3000), indices = c(3,8))
set.row(lprec, 10, c(1,-3000), indices = c(4,9))
set.row(lprec, 11, c(1,-3000), indices = c(5,10))
set.row(lprec, 12,c(1,1), indices =c(6,7)) 
set.row(lprec, 13,c(-1,1), indices =c(3,5))  


set.rhs(lprec, c(10000,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	1,	0))


set.constr.type(lprec, c("=",	"<=",	"<=","<=","<=","<=",">=",">=",">=",">=",">=","<=",">="))

set.type(lprec, c(1:5),"real")

set.type(lprec, c(6:10),"binary")

set.bounds(lprec, lower = rep(0, 10), upper = rep(Inf, 10))

# write.lp(lprec, filename="test.lp")  Use write.lp to print out larger LPs. 
#  It produces a text file, which you can examine with any text editor.


solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution
 
#get.constraints(lprec) 
