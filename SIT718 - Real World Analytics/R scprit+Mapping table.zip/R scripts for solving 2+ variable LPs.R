
###############################
###############################

# 8.6 Bank Loans

# The varible mapping index table is in the Excel(Bank Loans) 


library(lpSolveAPI)



lprec <- make.lp(0, 5) # five variables

lp.control(lprec, sense= "maximize") #  can change sense to  "maximize/minimize"



set.objfn(lprec, c(0.06497, 0.011468, 0.014814, 0.06875, 0.0505))

add.constraint(lprec, c(1, 1, 1, 1, 1), "<=", 12)

add.constraint(lprec, c(0.4, 0.4, 0.4, -0.6, -0.6), "<=", 0)

add.constraint(lprec, c(0.5, 0.5, -0.5, 0, 0), "<=", 0)

add.constraint(lprec, c(0.06, 0.03, -0.01, 0.01, 0.005), "<=", 0)


set.type(lprec, c(1:5),"real")

set.bounds(lprec, lower = rep(0, 5), upper = rep(Inf, 5))

RowNames <- c("Constraint 1", "Constraint 2", "Constraint 3", 'Constraint 4')

ColNames <- c("Personal", "Car", "Home", "Farm","Commercial")

dimnames(lprec) <- list(RowNames, ColNames)


lprec


solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

get.objective(lprec)

get.variables(lprec)

get.constraints(lprec) 


###############################
###############################

# 8.7 Blending Crude Oils into Gasolines

# The varible mapping index table is in the Excel(Blending Crude Oils) 


library(lpSolveAPI)


lprec <- make.lp(13, 12) # 12 variables and 13 constraints

lp.control(lprec, sense= "maximize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(21,	11,	1,	31,	21,	11,	41,	31,	21,	-1,	-1,	-1)) # set objective function

# set constraints
set.row(lprec, 1, c(1,1,1,-10), indices = c(1,4,7,10))
set.row(lprec, 2, c(1,1,1,-10), indices = c(2,5,8,11))
set.row(lprec, 3, c(1,1,1,-10), indices = c(3,6,9,12))
set.row(lprec, 4,rep(1,3), indices =c(1:3))
set.row(lprec, 5,rep(1,3), indices =c(4:6))
set.row(lprec, 6,rep(1,3), indices =c(7:9))
set.row(lprec, 7,rep(1,9), indices =c(1:9))
set.row(lprec, 8,c(2,-4,-2), indices =c(1,4,7))
set.row(lprec, 9,c(4,-2), indices =c(2,5))
set.row(lprec, 10,c(6,2), indices =c(3,9))
set.row(lprec, 11,c(-0.005,0.01,0.02), indices =c(1,4,7)) 
set.row(lprec, 12,c(-0.015,0.01), indices =c(2,8)) 
set.row(lprec, 13,c(-0.005,0.01,0.02), indices =c(3,6,9))  


set.rhs(lprec, c(3000,	2000,	1000,	5000,	5000,	5000,	14000,	0,	0,	0,	0,	0,	0))


set.constr.type(lprec, c("=",	"=",	"=", "<=",	"<=",	"<=",	"<=",	">=", 
                         ">=",	">=",	"<=",	"<=",	"<="))

set.type(lprec, c(1:12),"real")

set.bounds(lprec, lower = rep(0, 12), upper = rep(Inf, 12))

# write.lp(lprec, filename="test.lp")  Use write.lp to print out larger LPs. 
#  It produces a text file, which you can examine with any text editor.


solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution
sum(solution[c(1,4,7)])
sum(solution[c(2,5,8)])
sum(solution[c(3,6,9)])
#get.constraints(lprec) 



###############################
###############################

# 8.8 Transportation Models 

# Electric Power Plants

# The varible mapping index table is in the Excel(Electric Power Plants) 

library(lpSolveAPI)


lprec <- make.lp(7, 12) # 12 variables and 7 constraints

lp.control(lprec, sense= "minimize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(8,6,10,9,9,12,13,7,14,9,16,5)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,4), indices = c(1:4))
set.row(lprec, 2, rep(1,4), indices = c(5:8))
set.row(lprec, 3, rep(1,4), indices = c(9:12))
set.row(lprec, 4,rep(1,3), indices =c(1,5,9))
set.row(lprec, 5,rep(1,3), indices =c(2,6,10))
set.row(lprec, 6,rep(1,3), indices =c(3,7,11))
set.row(lprec, 7,rep(1,3), indices =c(4,8,12)) 


set.rhs(lprec, c(72, 50, 78, 45, 70, 30, 55))


set.constr.type(lprec, c("<=",	"<=",	"<=", ">=", ">=",	">=",	">="))

set.type(lprec, c(1:12),"real")

set.bounds(lprec, lower = rep(0, 12), upper = rep(Inf, 12))

# write.lp(lprec, filename="test.lp")  Use write.lp to print out larger LPs. 
#  It produces a text file, which you can examine with any text editor.


solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution

 
###############################


# Excess Demand & Using Dummy Demand Points

# The varible mapping index table is in the Excel(Using Dummy Demand Points) 

library(lpSolveAPI)


lprec <- make.lp(8, 15) # 15 variables and 8 constraints

lp.control(lprec, sense= "minimize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(8,6,10,9,9,12,13,7,14,9,16,5,0,0,0)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,5), indices = c(1:4,13))
set.row(lprec, 2, rep(1,5), indices = c(5:8,14))
set.row(lprec, 3, rep(1,5), indices = c(9:12,15))
set.row(lprec, 4,rep(1,3), indices =c(1,5,9))
set.row(lprec, 5,rep(1,3), indices =c(2,6,10))
set.row(lprec, 6,rep(1,3), indices =c(3,7,11))
set.row(lprec, 7,rep(1,3), indices =c(4,8,12)) 
set.row(lprec, 8,rep(1,3), indices =c(13:15)) 

set.rhs(lprec, c(72, 60,	78,	45,	70,	30,	55,10))


set.constr.type(lprec, c("<=",	"<=",	"<=", ">=", ">=",	">=",	">=",">="))

set.type(lprec, c(1:15),"real")

set.bounds(lprec, lower = rep(0, 15), upper = rep(Inf, 15))



solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution

#write.lp(lprec, filename="test.lp")  #Use write.lp to print out larger LPs. 

############################### 

# Handling Shortages

# The varible mapping index table is in the Excel(Handling Shortages) 

library(lpSolveAPI)


lprec <- make.lp(7, 16) # 16 variables and 7 constraints

lp.control(lprec, sense= "minimize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(8,6,10,9,9,12,13,7,14,9,16,5,100,120,115,130)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,4), indices = c(1:4))
set.row(lprec, 2, rep(1,4), indices = c(5:8))
set.row(lprec, 3, rep(1,4), indices = c(9:12))
set.row(lprec, 4,rep(1,4), indices =c(1,5,9,13))
set.row(lprec, 5,rep(1,4), indices =c(2,6,10,14))
set.row(lprec, 6,rep(1,4), indices =c(3,7,11,15))
set.row(lprec, 7,rep(1,4), indices =c(4,8,12,16)) 

set.rhs(lprec, c(60,	50,	70,	45,	70,	30,	55))


set.constr.type(lprec, c("<=",	"<=",	"<=", ">=", ">=",	">=",	">="))

set.type(lprec, c(1:16),"real")

set.bounds(lprec, lower = rep(0, 16), upper = rep(Inf, 16))



solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution
#write.lp(lprec, filename="test.lp")  #Use write.lp to print out larger LPs. 


############################### 

# Handling SHORTAGES Task

# The varible mapping index table is in the Excel(SHORTAGES Task) 

library(lpSolveAPI)


lprec <- make.lp(5, 9) # 9 variables and 5 constraints

lp.control(lprec, sense= "minimize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(7,8,10,9,7,8,20,22,23)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,3), indices = c(1:3))
set.row(lprec, 2, rep(1,3), indices = c(4:6))
set.row(lprec, 3, rep(1,3), indices = c(1,4,7))
set.row(lprec, 4,rep(1,3), indices =c(2,5,8))
set.row(lprec, 5,rep(1,3), indices =c(3,6,9)) 

set.rhs(lprec, c(40,60,40,30,50))


set.constr.type(lprec, c("<=",	"<=", ">=", ">=",	">="))

set.type(lprec, c(1:9),"real")

set.bounds(lprec, lower = rep(0, 9), upper = rep(Inf, 9))



solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution
#write.lp(lprec, filename="test.lp")  #Use write.lp to print out larger LPs. 


###############################
###############################

# 8.9 Inventory Problem

# The varible mapping index table is in the Excel(Inventory Problem) 

# Generate index table
#m <- c(1:45)
#Index <- matrix(m, nrow = 9, ncol = 5,byrow = TRUE)

library(lpSolveAPI)


lprec <- make.lp(14, 45) # 45 variables and 14 constraints

lp.control(lprec, sense= "minimize") #  can change sense to  "maximize/minimize"

M<-500000

set.objfn(lprec, c(0,20,40,60,0,
                   400,420,440,460,0,
                   450,470,490,510,0,
                   M, 400, 420, 440,0,
                   M, 450, 470, 490, 0,
                   M, M, 400, 420, 0,
                   M, M, 450, 470, 0,
                   M, M, M, 400, 0,
                   M, M, M, 450, 0)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,5), indices = c(1:5))
set.row(lprec, 2, rep(1,5), indices = c(6:10))
set.row(lprec, 3, rep(1,5), indices = c(11:15))
set.row(lprec, 4, rep(1,5), indices =c(16:20))
set.row(lprec, 5, rep(1,5), indices =c(21:25)) 
set.row(lprec, 6, rep(1,5), indices = c(26:30))
set.row(lprec, 7, rep(1,5), indices = c(31:35))
set.row(lprec, 8, rep(1,5), indices = c(36:40))
set.row(lprec, 9, rep(1,5), indices =c(41:45))
set.row(lprec, 10, rep(1,9), indices =seq(from = 1, to = 41, by = 5))
set.row(lprec, 11, rep(1,9), indices =seq(from = 2, to = 42, by = 5))
set.row(lprec, 12, rep(1,9), indices =seq(from = 3, to = 43, by = 5))
set.row(lprec, 13, rep(1,9), indices =seq(from = 4, to = 44, by = 5))
set.row(lprec, 14, rep(1,9), indices =seq(from = 5, to = 45, by = 5))


set.rhs(lprec, c(10,40,150,40,150,40,150,40,150,
                 40,60,75,25,570))


set.constr.type(lprec, c("<=","<=", "<=","<=","<=", "<=","<=","<=", "<=",   
                         ">=",">=",">=",">=",">="))

set.type(lprec, c(1:45),"real")

set.bounds(lprec, lower = rep(0, 45), upper = rep(Inf, 45))



solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution<- matrix(solution, nrow = 9, ncol = 5,byrow = TRUE) # reshape the varible values
solution 
#write.lp(lprec, filename="test.lp")  #Use write.lp to print out larger LPs. 



###############################
###############################

# 8.10 Assignment Problem

# The varible mapping index table is in the Excel(Assignment Problem) 

#m <- c(1:16)
#Index <- matrix(m, nrow = 4, ncol = 4,byrow = TRUE)

library(lpSolveAPI)


lprec <- make.lp(8, 16) # 16 variables and 8 constraints

lp.control(lprec, sense= "minimize") #  can change sense to  "maximize/minimize"

set.objfn(lprec, c(14, 5, 8, 7,2, 12, 6,5,7, 8, 3, 9,2, 4, 6, 10)) # set objective function

# set constraints
set.row(lprec, 1, rep(1,4), indices = c(1:4))
set.row(lprec, 2, rep(1,4), indices = c(5:8))
set.row(lprec, 3, rep(1,4), indices = c(9:12))
set.row(lprec, 4, rep(1,4), indices =c(13:16))
set.row(lprec, 5, rep(1,4), indices =seq(from = 1, to = 13, by = 4))
set.row(lprec, 6, rep(1,4), indices =seq(from = 2, to = 14, by = 4))
set.row(lprec, 7, rep(1,4), indices =seq(from = 3, to = 15, by = 4))
set.row(lprec, 8, rep(1,4), indices =seq(from = 4, to = 16, by = 4)) 


set.rhs(lprec, rep(1,8))


set.constr.type(lprec, rep("=",	8))

set.type(lprec, c(1:16),"binary")

set.bounds(lprec, lower = rep(0, 16), upper = rep(1, 16))



solve(lprec) # http://lpsolve.sourceforge.net/5.5/solve.htm

objvalue<-get.objective(lprec)
objvalue
solution<-get.variables(lprec)
solution<- matrix(solution, nrow = 4, ncol = 4,byrow = TRUE) # reshape the varible values
solution 

#write.lp(lprec, filename="test.lp")  #Use write.lp to print out larger LPs. 

