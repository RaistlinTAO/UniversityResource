<html>
<body>

	form submitted
	
	<?
		echo "<h1 style='color:red'>hello world</h1>";

		//use oci functions 
		//to communicate with Oracle database
		
		//connect to database
		//$connect=ocilogon('atuls','ssid1','SSID');
		$connect=ocilogon('gnasierd','080808','SSID');
		
		//create SQL statements
		$sql="insert into userdata values('$un','$em','$age', '$comments')";
		
		echo "$sql";
		
		//parse the SQL statements
		$stmt=ociparse($connect, $sql);
		
		//execute the SQL statement
		ociexecute($stmt);
		
		
	?>
	

</body>
</html>