<html>
<body>

	form submitted
	
	<?
		echo "<h1 style='color:red'>hello world</h1>";

		//use oci functions 
		//to communicate with Oracle database
		
		//connect to database
		//$connect=ocilogon('atuls','ssid1','SSID');
		$connect=ocilogon('gnasierd','080808','SSID');
		
		//create SQL statements
		$sql="select * from userdata";
		
		
		echo "$sql";
		
		//parse the SQL statements
		$stmt=ociparse($connect, $sql);
		
		//execute the SQL statement
		ociexecute($stmt);
		
		while(ocifetch($stmt)){
			echo "<br>";
			echo ociresult($stmt,1);
			echo ", ";
			echo ociresult($stmt,2);
			echo ", ";
			echo ociresult($stmt,3);
			echo ", ";
			echo ociresult($stmt,4);
			echo "<br>";
		}
		
	?>
	

</body>
</html>