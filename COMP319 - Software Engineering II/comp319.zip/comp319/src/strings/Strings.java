package strings;


import java.util.Hashtable;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Strings {
      
	  private static final String PREFIX="TEXT_";
	
      private Hashtable <String,String>allStrings=new Hashtable <String,String>();
      
      private static Strings instance=null;
      
      private void loadStrings(String fileName) {
    	  try {
    	  BufferedReader reader = new BufferedReader(new FileReader(fileName));
    	  
			String line = reader.readLine();
			while (line!=null) {
				if (line.startsWith(PREFIX)) {
					// found a string definition
					int commaPos=line.indexOf(",");
					if (commaPos!=-1) {
						String key=line.substring(0,commaPos);
						String value=line.substring(commaPos+1);
						allStrings.put(key, value);
					}
				}
				line = reader.readLine();
			}
			reader.close();
    	  } catch (IOException exc) {
    		  System.out.println("Problem loading "+fileName);
    	  }

      }
      
      public static Strings getInstance() {
    	  if (instance==null)
    	  {
    		  instance=new Strings();
    	  }
    	  return(instance);
      }
      
      private Strings() {
      }
      
      public void setLanguage(String lang) throws Exception {
    	    this.lang=lang;
            switch(lang) {
            case "en" :
            case "cn" :
            case "fr" :
                      loadStrings("strings."+lang);
                  break;
            default :
                  throw new Exception("Unknown language exception");
            }
      }

      
      private void put(String key,String string) {
            allStrings.put(key,string);
      }
      
      /**
       * Google translated, needs proof reading
       */


      private String lang="";

      public String getString(String key) {
    	    key=PREFIX+key;	// add prefix on
            if (lang.equals("")) {
               try {
                  setLanguage("en");
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
            }
            }
            if (allStrings.containsKey(key)) {
                  return(allStrings.get(key));
            }
            return("Undefined "+key);
      }
      
      
      
}

