package strings;

//import static Strings.YES;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//Strings.getInstance().setLanguage("cn");
			Strings.getInstance().setLanguage("fr");
			String yes=Strings.getInstance().getString("YES");
			String no=Strings.getInstance().getString("NO");
			System.out.println("Value of Yes is "+yes);
			System.out.println("Value of No is "+no);
			
			System.out.println("Value of LOGIN is "+Strings.getInstance().getString("LOGIN"));
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}

}
