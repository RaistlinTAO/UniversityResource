package dynamicpoly;

public interface IShape {
	public double getArea();

}
