package dynamicpoly;

public class Main {

	public static void main(String[] args) {
		IShape shape1=new Rectangle(400,500);
		
		IShape shape2=new Circle(100);
		
		
		System.out.println("Area of rectangle is "+shape1.getArea());
		
		System.out.println("Area of circle is "+shape2.getArea());
		
		// Notice the decision of which implementation of getArea to call is only know at run-tume
		// this is why the polymorphism is called dynamic
		
		shape2=new Rectangle(20,30);
		
		// calling shape2.getArea again, but new code called, method is not determined by IShape, only signature
		
		System.out.println("Area of rectangle is "+shape2.getArea()); 
		
		// There is a difference between the type of the reference in this case IShape

		// and the type of the object being referenced
		
		
	}

}
