package dynamicpoly;

public class Rectangle implements IShape {
	private int length,width;
	public Rectangle(int length,int width) {
		this.length=length;
		this.width=width;
	}
	
	@Override	
	public double getArea() {
		return(width*length);
	}
	

}
