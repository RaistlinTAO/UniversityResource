package mvcexample.control;

import java.awt.event.*;

import  mvcexample.view.*;
import mvcexample.model.*;

public class CustomerControl implements ActionListener {

	private CustomerView view;
	private Customer customer;
	
	
	public CustomerControl(CustomerView view,Customer customer) {
		this.view=view;
		this.customer=customer;
	}
	
	
	private boolean isvalid() {
		view.setError(""); // clear out error first
		if (view.getSurname().length()<2) {
			view.setError("Surname invalid");
			return(false);
		}
		if (view.getForenames().length()<2) {
			view.setError("Forename invalid");
			return(false);
		}
		
		
		return(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// We have two actions from this view, update the object or cancel
		if (view.isUpdateClick(e)) {
			if (isvalid()) {		// validate the details for the customer
				// Now update the model from the customers details
				customer.setForenames(view.getForenames());
				customer.setSurname(view.getSurname());	
				customer.save();
				view.refresh();  // update the UI
			}
		}
		if (view.isCancelClick(e)) {
			view.close();
		}
	}

}
