package mvcexample.model;

import java.util.Date;

// TO DO add in field validation and Database access logic

public class Customer {
	private int customerID;
    private String surname;
    private String forenames;
    private Date dateOfBirth;
	public String getSurname() {
		return surname;
	}
	
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getForenames() {
		return forenames;
	}
	public void setForenames(String forenames) {
		this.forenames = forenames;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
    
	
	public void save() {
		// TO DO ... add in code to update database
		System.out.println("Saving to database");
	}
}
