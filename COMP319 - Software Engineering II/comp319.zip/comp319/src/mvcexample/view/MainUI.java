package mvcexample.view;

import mvcexample.model.*;

import java.awt.event.WindowEvent;

import java.awt.event.WindowListener;
import java.awt.Dimension;
import java.awt.Toolkit;


import javax.swing.JFrame;

public class MainUI extends JFrame implements WindowListener {
	
	
	public MainUI() {
		this.getContentPane().setLayout(null);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setSize(new Dimension(400,400));
		this.setVisible(true);
	}
	
	/**
	 * Add customer to main UI
	 * @param customer
	 */
	public void addCustomer(Customer customer) {
		CustomerView cv=new CustomerView(customer);
		add(cv);
		revalidate();
		repaint();

	}
	

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		this.dispose();
		System.exit(1);
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

}
