package mvcexample.view;

import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;

import mvcexample.model.Customer;

public class CustomerView extends JPanel {
	
	private Customer customer;		// customer instance tied to this View
	
	private JTextField surnameField;
	private JTextField forenamesField;
	
	private JLabel surnameValue;
	private JLabel surnameCaption;
	
	private JLabel forenamesValue;
	private JLabel forenamesCaption;
	
	private JButton update=new JButton();
	
	private JButton cancel=new JButton();
	
	private JLabel padding=new JLabel();
	
	private JLabel error=new JLabel();
	
	
	/**
	 * Create a view for associated Customer
	 * @param person
	 */
	public CustomerView(Customer customer) {
		this.customer=customer;
		JPanel container =new JPanel();
		setBorder(new EmptyBorder(10, 10, 10, 10));
		Border raisedetched = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
		container.setBorder(raisedetched);
		
		surnameField=new JTextField();
		surnameCaption=new JLabel();
		surnameValue=new JLabel();
		
		forenamesField=new JTextField();
		forenamesCaption=new JLabel();
		forenamesValue=new JLabel();
		
		surnameField.setText(customer.getSurname());
		surnameCaption.setText(strings.Strings.getInstance().getString("SURNAME"));
		
		surnameValue.setText(customer.getSurname());
		container.add(surnameCaption);
		container.add(surnameValue);
		container.add(surnameField);
		
		forenamesField.setText(customer.getForenames());
		forenamesCaption.setText(strings.Strings.getInstance().getString("FORENAMES"));
		
		forenamesValue.setText(customer.getForenames());
		container.add(forenamesCaption);
		container.add(forenamesValue);
		container.add(forenamesField);
		
		update.setText(strings.Strings.getInstance().getString("UPDATE"));
		cancel.setText(strings.Strings.getInstance().getString("CANCEL"));
		System.out.println("Setting string to "+strings.Strings.getInstance().getString("UPDATE"));
		
		
		container.add(padding);
		container.add(update);
		container.add(cancel);
		container.add(error);
		
		
		
		container.setLayout(new GridLayout(4,3,20,20));
		this.add(container);
		container.setSize(400,200);
		this.setSize(400,200);
		//container.setVisible(true);
		this.setVisible(true);
		mvcexample.control.CustomerControl control=new mvcexample.control.CustomerControl(this,customer);
		// Now tie the controller to the inputs on this view
		this.update.addActionListener(control);
		this.cancel.addActionListener(control);
		
	}
	
	public void refresh() {
		forenamesField.setText(customer.getForenames());
		forenamesValue.setText(customer.getForenames());
		surnameField.setText(customer.getSurname());
		surnameValue.setText(customer.getSurname());		
	}
	
	public boolean isUpdateClick(ActionEvent event) {
		return(event.getSource()==update);
	}
	
	public boolean isCancelClick(ActionEvent event) {
		return(event.getSource()==cancel);
	}
	
	public void close() {
		setVisible(false);
	}

	
	
	public String getSurname() {
		return(this.surnameField.getText());
	}
	
	public String getForenames() {
		return(this.forenamesField.getText());
	}
	
	public void setError(String errorMessage) {
		this.error.setText(errorMessage);
	}

}
