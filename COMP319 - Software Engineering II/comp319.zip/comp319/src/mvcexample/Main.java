package mvcexample;

import java.awt.*;

import mvcexample.view.MainUI;

import mvcexample.model.Customer;
import mvcexample.view.CustomerView;

public class Main {

	public static void main(String[] args) {
		MainUI ui=new MainUI();
		Customer customer=new Customer();
		customer.setForenames("");
		customer.setSurname("");
		
		ui.addCustomer(customer);
	}

}
