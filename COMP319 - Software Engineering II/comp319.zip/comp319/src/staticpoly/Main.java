package staticpoly;

public class Main {

	public static void main(String[] args) {
		Stack <Integer> integerStack=new Stack <Integer>();
		Integer i1=Integer.valueOf(20);
		integerStack.push(i1);
		i1=Integer.valueOf(200);
		integerStack.push(i1);

		Integer i2=integerStack.pop();
		
		System.out.println("Value is "+i2.intValue());
		
		Stack <String> stringStack=new Stack <String>();
		
		String s1="Seb";
		String s2="Coope";
		
		stringStack.push(s1);
		stringStack.push(s2);
		
		stringStack.pop();
		
		System.out.println("Stack pop is "+stringStack.pop());
		
		// Now we will try and push the wrong type, uncomment the following line and see what happens
		
		//stringStack.push(i1);
		
		stringStack.testType();

	}

}
