package staticpoly;

import java.lang.reflect.Array;

// T is the type of the item being stored
public  class Stack <E> {
	
	private int MAX_SIZE=20000;		// currently fixed, option TO DO ... add in as argument to constructor
	E v;
	int stackPointer=0;
	
	private E[] stackData;			// where data will be stored, note we have erased type on storage
	
	// Constructor for stack
	public Stack() {
		stackData=(E[]) new Object[MAX_SIZE];  // Cannot use E to define type of array for initialisation
	}	
	
	public E pop() {
		if (stackPointer==0) {
			throw new RuntimeException("Stack empty exception");
		}
		stackPointer--;
		v=stackData[stackPointer];			// Notice this conversion is unchecked, must match push
											// Not a big problem as we can easily check this by hand
		
		return(v);
	}
	
	public void testType() {
//		E testVar=new E();   
	}
	
	public void push(E value) {
		if (stackPointer==MAX_SIZE-1) {
			throw new RuntimeException("Stack full exception");
		}
		stackData[stackPointer++]=value;
	}
	
	

}
