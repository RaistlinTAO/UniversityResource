package interfaceseperation;

public class PDFDocument {

}
