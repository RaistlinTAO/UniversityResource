package interfaceseperation;

import java.awt.Graphics;

public class Circle implements IShape,IPDFExportable,IRenderable {

	private int radius;
	
	public Circle(int radius) {
		this.radius=radius;
	}

	@Override
	public PDFDocument exportToPDFDocument() {
		System.out.println("Exporting Circle to PDF");
		return(null);
	}
	
	
	@Override
	public void render(Graphics graphics) {
		System.out.println("Painting circle");		
	}
	
	
	
	@Override
	public double getArea() {
		return Math.PI*radius*radius;		// return area for circle
	}

}
