package interfaceseperation;

public interface IPDFExportable {
	PDFDocument exportToPDFDocument();

}
