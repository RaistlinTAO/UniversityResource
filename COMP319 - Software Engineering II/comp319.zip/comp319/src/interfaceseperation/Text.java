package interfaceseperation;

import java.awt.Graphics;

public class Text implements IRenderable, IPDFExportable {
	
	private String textString;
	private int x,y;
	
	
	public Text(String textString,int x,int y) {
		this.textString=textString;
		this.x=x;
		this.y=y;
	}

	@Override
	public PDFDocument exportToPDFDocument() {
		System.out.println("Exporting text to PDF document");
		return(null);
	}

	@Override
	public void render(Graphics graphics) {
		System.out.println("Paint text "+this.textString+" at "+x+" , "+y);

	}

}
