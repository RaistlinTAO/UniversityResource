package interfaceseperation;

public class Main {

	public static void main(String[] args) {
		
		IRenderable renderItems[]=new IRenderable[4];
		
		renderItems[0]=new Rectangle(400,500);
		renderItems[1]=new Circle(100);
		renderItems[2]=new Image();
		renderItems[3]=new Text("Hello World!!",40,40);
		
		
		for (int idx=0;idx<4;idx++) {
			renderItems[idx].render(null);
		}
		
		IPDFExportable pdfItems[]=new IPDFExportable [4];
		
		pdfItems[0]=new Rectangle(400,500);
		pdfItems[1]=new Circle(100);
		pdfItems[2]=new Image();
		pdfItems[3]=new Text("Hello World!!",40,40);
		
		for (int idx=0;idx<4;idx++) {
			pdfItems[idx].exportToPDFDocument();
		}
		
		
		
		
		
		
		
				
		
	}

}
