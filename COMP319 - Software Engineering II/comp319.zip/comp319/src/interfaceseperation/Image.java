package interfaceseperation;

import java.awt.Graphics;

public class Image implements IPDFExportable, IRenderable {

	@Override
	public void render(Graphics graphics) {
		System.out.println("Painting image");
		
	}

	@Override
	public PDFDocument exportToPDFDocument() {
		System.out.println("Exporting image to PDF document");
		return null;
	}

}
