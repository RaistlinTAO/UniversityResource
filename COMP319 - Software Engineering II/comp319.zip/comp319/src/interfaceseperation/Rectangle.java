package interfaceseperation;

import java.awt.Graphics;

public class Rectangle implements IShape, IPDFExportable,IRenderable { 
	private int length,width;
	public Rectangle(int length,int width) {
		this.length=length;
		this.width=width;
	}
	
	@Override	
	public double getArea() {
		return(width*length);
	}
	
	
	@Override
	public PDFDocument exportToPDFDocument() {
		System.out.println("Exporting Rectangle to PDF");
		return(null);
	}
	
	
	@Override
	public void render(Graphics graphics) {
		System.out.println("Painting Rectangle");		
	}
	
	

}
