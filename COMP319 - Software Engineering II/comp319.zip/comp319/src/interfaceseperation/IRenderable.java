package interfaceseperation;

import java.awt.Graphics;

public interface IRenderable {
	void render(Graphics graphics);

}
