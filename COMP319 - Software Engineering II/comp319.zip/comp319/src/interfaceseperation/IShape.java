package interfaceseperation;

public interface IShape {
	public double getArea();

}
