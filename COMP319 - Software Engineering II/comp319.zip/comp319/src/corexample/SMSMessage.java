package corexample;

public class SMSMessage extends Message {
	
	private static final int MAX_LEN=160;

	public SMSMessage(String contents, String from, String to) {
		super(MessageType.SMS, contents, from, to);
		validateFields(contents,from,to);
	}

	private void validateFields(String contents, String from, String to) {
		if (contents.length()>MAX_LEN) {
			throw new RuntimeException("SMS contents too long maximum length is "+MAX_LEN);
		}
		for (int idx=0;idx<to.length();idx++) {
			if (!Character.isDigit(to.charAt(idx))) {
				throw new RuntimeException("SMS to field contains a non digit ");
			}
		}
	}

}
