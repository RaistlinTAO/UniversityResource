package corexample;

/*
 * Represents an electronic message
 * This base type can be extended to generate new message types with proper validation for fields
 */
public class Message implements IMessage {
	
	public Message(MessageType mytype, String contents, String from, String to) {
		super();
		this.mtype = mytype;
		this.contents = contents;
		this.from = from;
		this.to = to;
	}
	
	private MessageType mtype;
	private String contents;
	private String from;
	private String to;
	
	public final String getContents() {
		return contents;
	}
	public final String getFrom() {
		return from;
	}
	public final String getTo() {
		return to;
	}
	@Override
	public MessageType getMessageType() {
		return mtype;
	}
	

}
