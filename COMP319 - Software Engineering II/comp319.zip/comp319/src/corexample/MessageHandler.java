package corexample;

import java.util.Random;

public abstract class MessageHandler implements IMessageHandler {
	
	/**
	 * 
	 * @param mtype  Message type that this handler will deal with
	 */
	public MessageHandler(MessageType mtype) {
		super();
		this.mtype = mtype;
		addThisHandler();	// link into list
	}

	private MessageType mtype;
	
	private static MessageHandler firstHandler=null;		// points to the first handler in list
	
	private MessageHandler nextHandler=null;
	
	
	private void addThisHandler() {
		if (firstHandler==null) {		// if list is empty
			firstHandler=this;			// make this message the only message in queue
		} else {
			MessageHandler currentHandler=firstHandler;
			while (currentHandler.nextHandler!=null) {		// move down the list
				currentHandler=currentHandler.nextHandler;
			}
			// we now link this handler to the end of the list
			currentHandler.nextHandler=this;
		}
	}
	
	@Override
	public final MessageType getMessageType() {
		return(mtype);
	}
	
	/**
	 * 
	 * @return true is mnessage sent succesfully
	 */
	public static boolean dispatchMessage(IMessage message) {
		boolean okSend=false;
		MessageHandler currentHandler=firstHandler;
		while (currentHandler!=null) {			// move down the list, until we've run out of handlers
			if (currentHandler.getMessageType()==message.getMessageType()) {
				okSend=currentHandler.sendMessage(message);			
			}
			if (okSend) break;			// message sent so stop
			currentHandler=currentHandler.nextHandler;		// move down the list
		}
		
		return(okSend);
	}
	
	
	private static Random rng=null;
	/**
	 * helper method, use to simulate message being sent sometimes ok, sometimes not
	 * @return true message sent ok, false message sent failed
	 */
	protected final boolean sentOK() {
		if (rng==null) {
			rng=new Random(System.currentTimeMillis());
		}
		boolean ok=rng.nextBoolean();		// 50% chance of failure for simulation
		return(ok);
	}

}
