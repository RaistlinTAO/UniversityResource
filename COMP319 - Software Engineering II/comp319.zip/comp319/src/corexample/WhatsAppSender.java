package corexample;

public class WhatsAppSender extends MessageHandler {

	public WhatsAppSender() {
		super(MessageType.WHATSAPP);
	}

	@Override
	public boolean sendMessage(IMessage message) {
		// TODO send message via WhatsApp API
		
		// https://green-api.com/en/
		
		System.out.println("Trying to send message via WhatsApp");
		
		
		System.out.println("From "+message.getFrom()+" To "+message.getTo()+" contents "+message.getContents());

		// TODO   Send the message via GMail service
		
		boolean ok=this.sentOK();
		return ok;
	}

}
