package corexample;

public class SMTPHandler extends MessageHandler {

	private String provider;
	
	
	
	public SMTPHandler(String provider) {
		super(MessageType.EMAIL);
		this.provider=provider;
	}

	/**
	 * @return true is message sent ok
	 */
	public boolean sendMessage(IMessage message) {
		
		System.out.println("Trying to send email via "+provider);
		
		
		System.out.println("From "+message.getFrom()+" To "+message.getTo()+" contents "+message.getContents());

		// TODO   Send the message via Email SMTP service
		
		boolean ok=this.sentOK();
		return ok;		 
	}

}
