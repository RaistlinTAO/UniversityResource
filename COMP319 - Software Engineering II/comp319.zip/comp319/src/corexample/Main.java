package corexample;

public class Main {

	
	private void setUpChains() {
		IMessageHandler sender=new WhatsAppSender();
		sender=new SMTPHandler("smtp.plusnet.com");
		sender=new SMTPHandler("smtp.liverpool.ac.uk");
		sender=new GMailHandler();
		
	}
	
	
	private void testCOR() {
		setUpChains();
		
		IMessage whatsAppMessage=new Message(MessageType.WHATSAPP,"Your flight is delayed","Easyjet.com","077123345");
		IMessage emailMessage=new Message(MessageType.EMAIL,"Your flight is delayed","Easyjet.com","coopes@liv.ac.uk");
		
		IMessage smsMessage=new SMSMessage("Your flight is delayed","Easyjet.com","077123345");
		
		MessageHandler.dispatchMessage(whatsAppMessage);
		MessageHandler.dispatchMessage(smsMessage);
		MessageHandler.dispatchMessage(emailMessage);
		
	
	}
	
	
	public Main() {
	}

	public static void main(String[] args) {
		Main app=new Main();
		app.testCOR();
	}

}
