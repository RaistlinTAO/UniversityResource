package corexample;

public enum MessageType {
	SMS,
	EMAIL,
	WHATSAPP
}
