package corexample;

public interface IMessage {
	public MessageType getMessageType();
	
	public String getContents();
	
	public String getFrom();
	
	public String getTo();
}


