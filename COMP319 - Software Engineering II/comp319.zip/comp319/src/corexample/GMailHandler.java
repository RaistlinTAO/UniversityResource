package corexample;

public class GMailHandler extends MessageHandler {

	public GMailHandler() {
		super(MessageType.EMAIL);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean sendMessage(IMessage message) {

		System.out.println("Trying to send email via GMAIL");
		
		
		System.out.println("From "+message.getFrom()+" To "+message.getTo()+" contents "+message.getContents());

		// TODO   Send the message via GMail service
		
		boolean ok=this.sentOK();
		return ok;		 
	}

}
