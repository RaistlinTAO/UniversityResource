package corexample;

public interface IMessageHandler {
	
	public boolean sendMessage(IMessage message);

/**
 * 
 * @return The type of the message stored, SMS, WHATSAPP EMAIL etc
 */
	public MessageType getMessageType();

}

