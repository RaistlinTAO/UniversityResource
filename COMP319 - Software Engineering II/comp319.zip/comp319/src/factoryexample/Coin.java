package factoryexample;

/**
 * Note class is marked abstract to stop it being initiated directly
 * @author Admin
 *
 */
public abstract class Coin implements ICoin {
	private int value;
	private String name="";
	
	@Override
	public int getValue() {
		return(value);
	}
	@Override
	public String getName() {
		return(name);
	}
	
	@Override
	public abstract String getCurrencyCode();

	public void setValue(int value) {
		this.value = value;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	abstract public int [] getValidValues();
	
	abstract public String [] getValidNames();
	
	public void checkLegal(int value) {
		int [] validValues=this.getValidValues();
		String [] validNames=this.getValidNames();
		for (int idx=0;idx<validValues.length;idx++) {
			if (value==validValues[idx]) {	// we have found a value coin
				setName(validNames[idx]);
				return;	
			}
		}
		// Now valid coin found
		throw new InvalidCoinValueException("Bad coin value for "+this.getCurrencyCode()+" value is "+value);
	}
	
	
}
