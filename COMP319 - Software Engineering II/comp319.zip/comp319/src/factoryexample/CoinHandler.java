package factoryexample;


import java.util.*;


public abstract class CoinHandler {
	
	private Vector <ICoin>  allCoins=new Vector <ICoin>();
	
	public void addNewCoin(int value) {
		ICoin coin=makeCoin(value);	
		allCoins.add(coin);
	}
	
	public void dumpCoins() {
		for (int idx=0;idx<allCoins.size();idx++) {
			ICoin coin=allCoins.get(idx);
			System.out.println("Coin is "+coin.getName());
		}
	}
	
	abstract ICoin makeCoin(int value);

}
