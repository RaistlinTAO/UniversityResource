package factoryexample;

public class CoinHandlerGBP extends CoinHandler {

	@Override
	ICoin makeCoin(int value) {
		return new CoinGBP(value);
	}

}
