package factoryexample;

public class CoinHandlerUSD extends CoinHandler {

	@Override
	ICoin makeCoin(int value) {
		return new CoinGBP(value);	}

}
