package factoryexample;

public class CoinUSD extends Coin {
	
	private static final int validValues[]= {1,5,10,25,50,100 };
	private static final String validNames[]= {
			"1 cent","5 cent","10 cent","25 cent","50 cent","1 dollar" 
	};
	
	
	
	
	
	public CoinUSD(int value) {
		checkLegal(value);
		setValue(value);
		
	}





	@Override
	public final int[] getValidValues() {
		return validValues;
	}





	@Override
	public String[] getValidNames() {
		return(validNames);
	}




	@Override
	public final String getCurrencyCode() {
		return "USD";
	}

}
