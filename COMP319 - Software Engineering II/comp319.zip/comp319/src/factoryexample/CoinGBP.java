package factoryexample;

public class CoinGBP extends Coin {
	
	private static final int validValues[]= {1,5,10,20,50,100,200 };
	private static final String validNames[]= {
			"1 pence","5 pence","10 pence","25 pence","50 pence","1 pound","2 pounds" 
	};
	
	
	
	
	
	public CoinGBP(int value) {
		checkLegal(value);
		setValue(value);
		
	}





	@Override
	public final int[] getValidValues() {
		return validValues;
	}





	@Override
	public String[] getValidNames() {
		return(validNames);
	}




	@Override
	public final String getCurrencyCode() {
		return "GBP";
	}

}
