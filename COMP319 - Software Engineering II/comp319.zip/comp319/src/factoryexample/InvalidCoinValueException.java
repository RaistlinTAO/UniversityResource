package factoryexample;

public class InvalidCoinValueException extends RuntimeException {
	
	public InvalidCoinValueException(String message) {
		super(message);
	}
}
