package factoryexample;

public class Main {

	public static void main(String[] args) {
		CoinHandler handlerUSD=new CoinHandlerUSD();
		CoinHandler handlerGBP=new CoinHandlerGBP();
		
		handlerUSD.addNewCoin(1);
		handlerUSD.addNewCoin(5);
		handlerUSD.addNewCoin(100);
		handlerUSD.dumpCoins();
		
		handlerGBP.addNewCoin(1);
		handlerGBP.addNewCoin(5);
		handlerGBP.addNewCoin(20);
		handlerGBP.addNewCoin(100);
		handlerGBP.addNewCoin(200);
		
		handlerGBP.dumpCoins();
		
		handlerGBP.addNewCoin(25);       // test adding invalid coin
		
		
		
		
		

	}

}
