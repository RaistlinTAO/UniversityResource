package factoryexample;

public interface ICoin {

	int getValue();

	String getName();

	String getCurrencyCode();

}