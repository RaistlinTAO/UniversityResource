package dobvalidation;

import java.time.LocalDate;
import java.util.Date;

public class Main {

	public static void main(String[] args) {
		Person person=new Person();
		LocalDate dateOfBirth=LocalDate.of(1969,12,25);	// make dob
		person.setDateOfBirth(dateOfBirth);
		System.out.println("Set date of birth value stored is "+person.getDateOfBirth());
		dateOfBirth=LocalDate.of(2021,12,25);	// make dob in future!! invalid
		person.setDateOfBirth(dateOfBirth);
		System.out.println("Set date of birth value stored is "+person.getDateOfBirth());
		

	}

}
