package bankAccountExample.authenticateAspect;

public abstract class AuthenticatedObject {
	private String authenticationKey;	// This is a key associated with the user 
	public String getAuthenticationKey() {
		return(authenticationKey);
	}
	public void setAuthenticationKey(String authenticationKey) {
		this.authenticationKey = authenticationKey;
	}

}
