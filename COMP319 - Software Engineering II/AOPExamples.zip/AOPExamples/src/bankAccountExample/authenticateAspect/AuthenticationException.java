package bankAccountExample.authenticateAspect;

public class AuthenticationException extends RuntimeException {

}
