package bankAccountExample.authenticateAspect;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class AuthenticationDialog {
	private Dialog d;
	private String username="";
	private String password="";
	
	public AuthenticationDialog() {
	JFrame f= new JFrame();  
    d = new Dialog(f , "Enter username and password", true);  
    
    f.setLocationRelativeTo(null);
    d.setLayout(new GridLayout(0,2) );  
    d.setLocation(100,100);
    JPanel jp=new JPanel();
    jp.add( new JLabel ("Enter username and password"));  
    d.add(jp);
    d.add( new JLabel (""));  

    jp=new JPanel();
    jp.setLayout(new FlowLayout(FlowLayout.LEFT));
    
    
    jp=new JPanel();
    jp.setLayout(new FlowLayout(FlowLayout.LEFT));
    JLabel caption=new JLabel(expand("Username :",30));
    jp.add(caption);
    JTextField tfUsername=new JTextField();
    tfUsername.setMargin(new Insets(6,6,6,6));
    tfUsername.setPreferredSize(new Dimension(200,40));
     jp.add(tfUsername);
    caption.setAlignmentX(Component.LEFT_ALIGNMENT);
    tfUsername.setAlignmentX(Component.LEFT_ALIGNMENT);
    JLabel status=new JLabel();

    d.add(jp);
    d.add( new JLabel ("")); 
    
    jp=new JPanel();
    jp.setLayout(new FlowLayout(FlowLayout.LEFT));
    caption=new JLabel(expand("Password :",30));
    jp.add(caption);
    JTextField tfPassword=new JTextField();
    tfPassword.setMargin(new Insets(6,6,6,6));
    tfPassword.setPreferredSize(new Dimension(200,40));
    
    jp.add(tfPassword);
    d.add(jp);
    
    
    d.add( new JLabel (""));  
    
    d.add( new JLabel ("")); 
    
    d.add( new JLabel (""));  
    d.add( new JLabel (""));  
    d.add( new JLabel (""));  
    d.add( new JLabel (""));  
    
    jp=new JPanel();
    JButton b = new JButton ("OK");  
    b.setFont(new java.awt.Font("Arial", Font.BOLD, 18));
    b.setBackground(Color.LIGHT_GRAY);
    b.setForeground(Color.BLACK);
    d.addWindowListener(new WindowAdapter() {
    	public void windowClosing(WindowEvent e) {
    		d.setVisible(false);
    	}
    });
    	
    b.addActionListener ( new ActionListener()  
    {  
        public void actionPerformed( ActionEvent e )  
        {  
           // d.setVisible(false);  
        	// Closing 
        	password=tfPassword.getText();
        	username=tfUsername.getText();
        	d.setVisible(false);
        	
        }  
    });  
    jp.add(b);
    
    d.add(jp);   
    d.add(status);  
    
    d.pack();
    d.setVisible(true);  
	}

	private String expand(String string, int len) {
		if (string.length()<len) {
			string=string+"                                                        ".substring(0,len-string.length());
		}
		return(string);
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

}
