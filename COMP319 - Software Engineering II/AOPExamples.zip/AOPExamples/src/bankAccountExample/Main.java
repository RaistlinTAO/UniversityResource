package bankAccountExample;



public class Main {

	public static void main(String[] args) {
		BankAccount account=new BankAccount();
	System.out.println("Key is "+account.getAuthenticationKey());

	}

}
