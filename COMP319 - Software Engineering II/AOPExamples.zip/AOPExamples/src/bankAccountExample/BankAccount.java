package bankAccountExample;

import bankAccountExample.authenticateAspect.AuthenticatedObject;

public class BankAccount extends AuthenticatedObject {

}
