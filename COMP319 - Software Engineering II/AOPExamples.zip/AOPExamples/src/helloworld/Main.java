package helloworld;

/**
 * Hello World AOP example
 * @author coopes
 *
 */
public class Main {

	public static void main(String[] args) {
		Main main=new Main();
		main.hello();
	}
	
	public void hello() {
		System.out.println("Hello");
	}


}
