package authenticate;

public class HackedUser extends User {
	public HackedUser(String usern) {
		super(usern);
    }
	public boolean authenticate(String pass) {
		return(true);  // authenticate over-ridden
	}
}
