package authenticate;

public class Main {

	public static void main(String[] args) {
		HackedUser user=new HackedUser("coopes@liv.ac.uk");
		String password="secret";
		Account account=new Account(user);
		int balance=account.getBalance(password);
	}

}
