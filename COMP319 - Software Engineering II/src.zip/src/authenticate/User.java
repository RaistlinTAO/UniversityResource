package authenticate;

public class User implements IAuthenticator {
	String username, password;

	public User(String usern) {
		// to do  load password from usern
	}

	public boolean authenticate(String pass) {
		return (pass.equals(password));
	}

	public void setNewPassword(String newpass,String oldpass) {
          if (oldpass.equals(password)) {
                this.password=newpass;
                // save details on database
          }
	}
}
