package authenticate;

public interface IAuthenticator {
	public boolean authenticate(String password);

}
