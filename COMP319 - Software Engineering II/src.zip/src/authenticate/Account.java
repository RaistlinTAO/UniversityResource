package authenticate;

public class Account {
	private User user;
    private int balance;
	public Account(User user) {
		this.user = user;
	}

	public int getBalance(String password) {
		if (!user.authenticate(password)) {
			throw new SecurityException();
		}
		return (balance);
	}
}