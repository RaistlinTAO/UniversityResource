package ac.liv.comp319.sms;

import ac.liv.comp319.utils.Provider;
import ac.liv.comp319.utils.SystemProperties;

public abstract class SMSProvider  extends Provider {
	public static final int OK=1;
	public static final int ERROR=2;
	

	
	public int compareTo(SMSProvider other) {
		// TODO Auto-generated method stub
		if ((getPriority()==0) || (other.getPriority()==0)) { // if no priority set, then order by name
			return(this.getName().compareTo(other.getName()));
		}
		if (getPriority()>other.getPriority()) return(1);
		if (getPriority()<other.getPriority()) return(-1);
		return 0;
	}

	
	public abstract String getName();

	
	
	public SMSProvider() {
	   	
	}
	
	public SMSProvider clone() {
		try {
			return((SMSProvider)super.clone());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return(null);
	}
	
	public int sendSMS(String message,String telephone,String countryCode) {
		int ret=OK;
		// TODO Check Blacklist
		// TODO Do logging

		ret=onSendMessage(message, telephone, countryCode);
		return(ret);		
	}

	public int sendSMS(String message,String telephone,String countryCode,String from) {
		int ret=OK;
		// TODO Check Blacklist
		// TODO Do logging
		ret=onSendMessage(message, telephone, countryCode,from);
		return(ret);		
	}

	public abstract int costOfMessageInPence(String telephone,String countryCode);
	public abstract int onSendMessage(String message,String telephone,String countryCode);
	public abstract int onSendMessage(String message,String telephone,String countryCode,String from);
		
}
