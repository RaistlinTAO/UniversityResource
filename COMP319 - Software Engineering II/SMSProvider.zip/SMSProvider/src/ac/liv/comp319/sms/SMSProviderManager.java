package ac.liv.comp319.sms;

import java.util.ArrayList;
import java.util.Collections;

import ac.liv.comp319.utils.InterfaceLoader;

public class SMSProviderManager {
	private static SMSProviderManager instance=new SMSProviderManager();
	private SMSProviderList providerList=null;
	public synchronized static SMSProviderManager getInstance() {
		if (instance.providerList==null) {
			instance.providerList=new SMSProviderList();
		}
		instance.dumpProviders();
		return(instance);
	}
	
	public SMSProviderList getProviderList() {
		return providerList;
	}

	public void dumpProviders() {
		for (SMSProvider provider : providerList.getProviders()) {
			SMSProvider item=provider.clone();
			provider.setEnabled(true);
			System.out.println("Name is "+item.getName());
			System.out.println("Priority is "+item.getPriority());	
		}
		
	}
	public static void main(String arsgv[]) {
		getInstance().dumpProviders();
	}
	
	public int sendSMSMessage(String message,String telephone,String countryCode,String from) {
		   int status=SMSProvider.ERROR;
		   for (SMSProvider provider : providerList.getProviders()) {
				SMSProvider item=provider.clone();
				if (item.isEnabled()) {
					   int state=item.sendSMS(message, telephone, countryCode,from);
					   if (state==SMSProvider.OK) {
						   status=state;break;
					   }
				}
		   }   
		   return(status);
	}
	

}
