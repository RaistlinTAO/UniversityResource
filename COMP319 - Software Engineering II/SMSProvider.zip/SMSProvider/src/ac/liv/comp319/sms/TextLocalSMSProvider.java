package ac.liv.comp319.sms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URLConnection;

import ac.liv.comp319.utils.Log;
import ac.liv.comp319.utils.SystemProperties;

public class TextLocalSMSProvider extends SMSProvider {
	@Override
	public int costOfMessageInPence(String telephone, String countryCode) {
		return 4;
	}	

	@Override
	public String getName() {
		return ("SMSTEXTLOCAL");
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode,String from) {
		Log.INFO_LOG.write("Sending message via Text Local");
		String baseUrl=SystemProperties.getInstance().getStringProperty("TEXTLOCAL_REQUEST_URL");
		String key=SystemProperties.getInstance().getStringProperty("TEXTLOCAL_APIKEY");
		String request="apiKey="+key+"&sender="+from+"&message="+message+"&numbers="+countryCode+telephone;
		StringBuffer response=new StringBuffer();		
		try {
			// Create connector for SMS service
			java.net.URL requester=new java.net.URL(baseUrl);
			System.out.println("url :"+baseUrl);
			// get connection to remote server
			URLConnection connector=requester.openConnection();
			connector.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(connector.getOutputStream());
			wr.write(request);
			wr.flush();
			// Now get input stream to return response code
			BufferedReader rd = new BufferedReader(new InputStreamReader(connector.getInputStream()));
			String line="";
			while ((line = rd.readLine()) != null) {
				response.append(line);
			}
			rd.close();wr.close();	// close down to release resources
		} catch (MalformedURLException e) {
			e.printStackTrace();
			Log.ERROR_LOG.write(e);	// log error if creating URL gave problem
			return(ERROR);
		} catch (IOException e) {
			e.printStackTrace();
			Log.ERROR_LOG.write(e);	// log error if got I/O exception
			return(ERROR);
		}
		System.out.println("Response is "+response.toString());
		return OK;
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode) {
		// TODO Auto-generated method stub
		System.out.println("SENDING MESSAGE IN THIS CODE!! error");
		return ERROR;	// not implemented, always return error
	}

}
