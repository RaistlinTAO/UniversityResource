package ac.liv.comp319.sms;

import java.util.Vector;

public class AbcSMSProvider extends SMSProvider {

	@Override
	public String getName() {
		return "ABC";
	}
	
	Vector<Object> fred=new Vector<Object>();
	

	@Override
	public int costOfMessageInPence(String telephone, String countryCode) {
		// TODO Auto-generated method stub
		
		return 0;
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode, String from) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
