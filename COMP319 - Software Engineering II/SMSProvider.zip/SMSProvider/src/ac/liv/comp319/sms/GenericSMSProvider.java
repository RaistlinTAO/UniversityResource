package ac.liv.comp319.sms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URLConnection;
import java.util.Enumeration;
import java.util.Hashtable;

import ac.liv.comp319.utils.Log;

public class GenericSMSProvider extends SMSProvider {

	private int costOfMessage=0;
	private String name="";
	private String url="";
	private String msisdn="";
	private String from="";
	private String message="";
	private Hashtable <String,String> requestArguments=new Hashtable<String,String>();
	
	/**
	 * 
	 * @param name   Name of SMS provider
	 * @param url	 Service URL to request service from
	 * @param cost    Cost in pence of each SMS message
	 * @param requestArguments  name,value pair list of request parameters
	 */
	public GenericSMSProvider(String name,String url,int cost,Hashtable <String,String>requestArguments) {
		this.name=name;
		this.url=url;
		this.costOfMessage=cost;
		this.requestArguments=requestArguments;
	}
	
	
	/**
	 * Calculates cost of message given telephone number and country code
	 * @param telephone   Telephone number of target to determine cost for
	 * @param countryCode  Destination country code of target to determine cost for
	 * @return cost of message in pence
	 */
	@Override
	public int costOfMessageInPence(String telephone, String countryCode) {
		return costOfMessage;
	}

	/**
	 * @return Name of provider
	 * 
	 */
	@Override
	public String getName() {
		return name;
	}
	
	private String fixArgument(String value) {
		if (value.equals("$(msisdn)")) {
			return(msisdn);
		}
		if (value.equals("$(message)")) {
			return(message);
		}
		if (value.equals("$(from)")) {
			return(from);
		}		
		return(value);
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode, String from) {
		// First copy arguments to class attributes
		this.from=from;
		this.msisdn=countryCode+telephone;
		this.message=message;
		Log.INFO_LOG.write("Sending message via"+getName());
		String baseUrl=url;
		// Now we add the arguments in
		StringBuffer arguments=new StringBuffer();
		Enumeration <String> allKeys =requestArguments.keys();
		while (allKeys.hasMoreElements()) {
			String key=allKeys.nextElement();
			String value=requestArguments.get(key);
			value=fixArgument(value);
			arguments.append(key+"="+value+"&");						
		}
		String request=arguments.toString();
		StringBuffer response=new StringBuffer();
		try {
			// Create connector for SMS service
			java.net.URL requester=new java.net.URL(baseUrl);
			System.out.println("url :"+baseUrl);
			// get connection to remote server
			URLConnection connector=requester.openConnection();
			connector.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(connector.getOutputStream());
			wr.write(request);
			wr.flush();
			// Now get input stream to return response code
			BufferedReader rd = new BufferedReader(new InputStreamReader(connector.getInputStream()));
			String line="";
			while ((line = rd.readLine()) != null) {
				response.append(line);
			}
			rd.close();wr.close();	// close down to release resources
		} catch (MalformedURLException e) {
			Log.ERROR_LOG.write(e);	// log error if creating URL gave problem
			return(ERROR);
		} catch (IOException e) {
			Log.ERROR_LOG.write(e);	// log error if got I/O exception
			return(ERROR);
		}
		return OK;
	}
}
