package ac.liv.comp319.sms;

import java.util.Random;

import ac.liv.comp319.utils.Log;

public class TestSMSProvider extends SMSProvider {
	private static final String PROVIDER_NAME="TEST SMS";
	private static final int FAILURE_RATE=30;
	public  String getName() {
		return(PROVIDER_NAME);
	}
	@Override
	public int costOfMessageInPence(String telephone, String countryCode) {
		return 0;		// test message's cost nothing
	}
	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode) {
		Log.INFO_LOG.write("Sending via test SMS to "+telephone+" country code is "+countryCode+" message is "+message);
		// test message sender randomly fails
		Random rng=new Random(System.currentTimeMillis());
		int randNumber=Math.abs(rng.nextInt() % 100); // random number between 00-99 inclusive
		int ret=OK; // default is OK
		if (randNumber<FAILURE_RATE) {
			ret=ERROR;
			Log.WARNING_LOG.write("Message failed to send");
		}
		return ret;
	}
	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode, String from) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
