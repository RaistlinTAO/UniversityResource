package ac.liv.comp319.sms;

import java.util.ArrayList;

import ac.liv.comp319.utils.ProviderList;

public class SMSProviderList extends ProviderList {
	public SMSProviderList() {
		super(SMSProvider.class);
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList <SMSProvider> getProviders() {
		super.getProviders();	// fetch from type defs
		// Now load up providers from config
		return((ArrayList <SMSProvider>)super.getProviders());
	}
	
	public void addProvider(SMSProvider provider) {
		super.addProvider(provider);	// add into list
	}
	
	public void moveToTop(String providerName) {
	    int priorityCount=2;	// For all other providers, set priority 2,3, 4 etc
		for (SMSProvider provider : getProviders()) {
		   if (provider.getName().equals(providerName)) {
			   provider.setPriority(1);
		   } else {
			   provider.setPriority(priorityCount++);
		   }
		}
		
	}
    
}
