package ac.liv.comp319.sms;

public class DefSMSProvider extends SMSProvider {

	@Override
	public String getName() {
		return ("DEF");
	}

	@Override
	public int costOfMessageInPence(String telephone, String countryCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int onSendMessage(String message, String telephone,
			String countryCode, String from) {
		// TODO Auto-generated method stub
		return 0;
	}

}
