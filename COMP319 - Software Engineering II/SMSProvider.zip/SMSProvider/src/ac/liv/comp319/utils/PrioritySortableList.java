package ac.liv.comp319.utils;

import java.util.ArrayList;
import java.util.Collections;

import ac.liv.comp319.sms.SMSProvider;

public class PrioritySortableList {
	ArrayList <PriorityEnabled> plist;
	private void setupPriorities() {
		int maxPriority=0;
		for (PriorityEnabled item : plist) {
			if (item.getPriority()!=0) {
				maxPriority=Math.max(maxPriority,item.getPriority());
			}
		} maxPriority++;
		for (PriorityEnabled  item : plist) {
			if (item.getPriority()==0) {
				item.setPriority(maxPriority++);
			}
		}
	}

	protected void sort(ArrayList <PriorityEnabled> plist) {
		this.plist=plist;
		this.setupPriorities();
		Collections.sort(plist);
	}

}
