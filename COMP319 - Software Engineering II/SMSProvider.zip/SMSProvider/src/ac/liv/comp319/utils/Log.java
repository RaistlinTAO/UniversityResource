/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.liv.comp319.utils;

import java.util.Hashtable;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Calendar;
import java.io.FileWriter;
import java.io.File;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

/**
 * Simple Logging system, this will create persistant log files
 * @author Seb
 */
public class Log {
    // Used to write to log file
    private FileWriter mFileWriter=null;
    private static Hashtable <String,Log>allLogs=new Hashtable<String,Log>();

    /**
     * Refer to each log by its singleton name
     */
    public static final Log ERROR_LOG=getLog("error");
    public static final Log DEBUG_LOG=getLog("debug");
    public static final Log INFO_LOG=getLog("info");
    public static final Log WARNING_LOG=getLog("warning");


    public static Log getLog(String name) {
        if (allLogs.containsKey(name)) {
            return(allLogs.get(name));
        }
        Log log=new Log(name);
        allLogs.put(name, log); // save in cache
        return(log);
    }

    private String mFilename;   // name of file associate with log
    /**
     * Creates a log
     * @param name of log
     */
    public Log(String name) {
        Date date=new Date(System.currentTimeMillis());
        Calendar calender=Calendar.getInstance();
        mFilename=name+"_"+calender.get(Calendar.DAY_OF_MONTH)+"_"+calender.get(Calendar.MONTH)+"_"+calender.get(calender.YEAR)+".log";
        File f=new File(mFilename);
        if (!f.exists()) {
           write("Log started"); // new log file
        }
    }
    
    private void openLog() {
        try {
            if (mFileWriter==null) {
                mFileWriter=new FileWriter(mFilename,true);  // create or append!
            }
        } catch (Exception exc) {
            System.err.println("Error opening log");
            exc.printStackTrace();
        }
    }
    /**
     * Writes Exeception for log
     */
    public void write(Exception exception) {
        try {
            openLog();
            write("Exception "+exception.getMessage(),false);
            PrintWriter pw=new PrintWriter(mFileWriter);
            exception.printStackTrace(pw);  // write it out
            pw.flush();
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
    /**
     * Dumps message to log
     * @param message
     * @param stake  if true top of stack is included
     */
    private void write(String message,boolean stack) {
        try {
            if (mFileWriter==null) {
                mFileWriter=new FileWriter(mFilename,true);  // create or append!
            }
            StackTraceElement [] elements=Thread.currentThread().getStackTrace();
            String classname="";
            String methodname="";
            int linenumber=0;
            if (elements!=null) {
                classname=elements[2].getClassName();
                methodname=elements[2].getMethodName();
                linenumber=elements[2].getLineNumber();
            }
            Date date=new Date(System.currentTimeMillis());
            DateFormat sdf=SimpleDateFormat.getInstance();
            String outputs=sdf.format(date)+" "+classname+"."+methodname+" at line "+linenumber+" : "+message;
            mFileWriter.write(outputs+"\n"); // save to log file
            System.out.println("Writing .."+outputs);
            mFileWriter.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     *
     * @param message Message to write to log
     */
    public void write(String message) {
        write(message,true);    // include extra messaging
    }

    public static void testTheTrace() {
        Log log=getLog("debug");
        log.write("Test message!!!");
        try {
            String mistake=null;
            System.out.println("Mistake len"+mistake.length());
        } catch (Exception exc) {
            ERROR_LOG.write(exc);
        }
        ERROR_LOG.write("ERROR BAD FILE NAME...");
    }

    public static void main(String argsv[]) {
        testTheTrace();

    }

}
