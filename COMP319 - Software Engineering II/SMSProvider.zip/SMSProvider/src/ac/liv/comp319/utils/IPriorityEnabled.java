package ac.liv.comp319.utils;

public interface IPriorityEnabled {

}
