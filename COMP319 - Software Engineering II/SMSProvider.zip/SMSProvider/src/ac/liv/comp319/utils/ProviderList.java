package ac.liv.comp319.utils;

import java.util.ArrayList;
import java.util.Collections;

import ac.liv.comp319.sms.SMSProvider;

public class ProviderList extends PrioritySortableList {
   private InterfaceLoader loader=new InterfaceLoader();
   private Class providerType;
	private ArrayList <Provider>providers;
	@SuppressWarnings("unchecked")
	public ProviderList(Class providerType) {
		this.providerType=providerType;
		// 
	}
	
		
	/**
	 * @return the providers
	 */
	@SuppressWarnings("unchecked")
	public ArrayList getProviders() {
		loadAllProviders(providerType);
		return (ArrayList)providers;
	}
	
	@SuppressWarnings("unchecked")
	public void addProvider(Provider provider) {
		providers.add(provider);
		super.sort((ArrayList)providers);
	}


	@SuppressWarnings("unchecked")
	private void loadAllProviders(Class type) {
		if (providers==null) {
			providers=loader.getInterfaces(type);
			loadAllProviders(providerType);						
		}
		super.sort((ArrayList)providers);
	}
	
}
