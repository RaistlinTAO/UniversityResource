package ac.liv.comp319.utils;

import java.util.ArrayList;

public abstract class Provider extends PriorityEnabled implements Cloneable {
    public Provider() {
	}
    public boolean isEnabled() {
		String propertyName=enabledPropertyName();
		boolean enabled=SystemProperties.getInstance().getBooleanProperty(propertyName);
		return(enabled);		
	}

	private String enabledPropertyName() {
		return this.getClass().toString()+"."+getName()+"."+"Enabled";
	}

	public void setEnabled(boolean value) {
		String propertyName=enabledPropertyName();
		SystemProperties.getInstance().setProperty(propertyName, value);		
	}
}
