package ac.liv.comp319.utils;

public abstract class PriorityEnabled  implements Nameable, IPriorityEnabled, Comparable<PriorityEnabled> {
	public int getPriority() {
		String propertyName=this.priorityPropertyName();
		int priority=SystemProperties.getInstance().getIntProperty(propertyName);
		return(priority);
	}
	
	public void setPriority(int priority) {
		String propertyName=this.priorityPropertyName();
		SystemProperties.getInstance().setProperty(propertyName,priority);
	}

	public int compareTo(PriorityEnabled other) {
		if (this.getPriority()==other.getPriority()) return(0);
		if (this.getPriority()>other.getPriority()) return(1);
		return(-1);
	}
	public String priorityPropertyName() {
		return this.getClass().toString()+"."+getName()+"."+"Priority";
	}
	
	
}
