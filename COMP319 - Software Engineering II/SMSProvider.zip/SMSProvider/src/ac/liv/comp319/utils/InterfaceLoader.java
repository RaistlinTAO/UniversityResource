package ac.liv.comp319.utils;
import java.io.File;
import java.net.URL;
import java.util.*;

import ac.liv.comp319.sms.SMSProvider;
public class InterfaceLoader {
    public <T> ArrayList <T> getInterfaces(Class interfaceType)   {
		ArrayList <T> list=new ArrayList<T>();
	        String pckgname=interfaceType.getPackage().getName();
	System.out.println("Package name is :"+pckgname);

	        // Translate the package name into an absolute path
	        String name = new String(pckgname);
	        if (!name.startsWith("/")) {
	            name = "/" + name;
	        }
	        name = name.replace('.','/');

	        // Get a File object for the package
	System.out.println("Package name is :"+name);

	        URL url = interfaceType.getResource(name);
	        File directory = new File(url.getFile());
	        // New code
	        // ======
	        if (directory.exists()) {
	            // Get the list of the files contained in the package
	            String [] files = directory.list();
	System.out.println("Number of files is .."+files.length);

	            for (int i=0;i<files.length;i++) {
	        
	                // we are only interested in .class files
	                if (files[i].endsWith(".class")) {
	                  System.out.println("Name of file is :"+files[i]);

	                    // removes the .class extension
	                    String classname = files[i].substring(0,files[i].length()-6);
	                    try {
	                        // Try to create an instance of the object
	                        Object o = Class.forName(pckgname+"."+classname).newInstance();
	                        if (interfaceType.isInstance(o)) {
	                            System.out.println("Correct type");
	                            T interfaceInstance=(T)o;
	                            list.add(interfaceInstance);
	                            System.out.println("Loading "+o.getClass().toString());
	                        } else {
	                            System.out.println("Not command ..");
	                        }
	                    } catch (ClassNotFoundException cnfex) {
	                        System.err.println(cnfex);
	                    } catch (InstantiationException iex) {
	                        // We try to instantiate an interface
	                        // or an object that does not have a
	                        // default constructor
	                    } catch (IllegalAccessException iaex) {
	                        // The class is not public
	                    }
	                }
	            }
	        }
	 else {
	            System.out.println("Could not find dir..");
	 }
	    

		return(list);
		
	}
	
	public static void main(String argsv[]) {
		
	}
}
