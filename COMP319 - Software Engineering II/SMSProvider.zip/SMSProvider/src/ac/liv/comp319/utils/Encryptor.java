package ac.liv.comp319.utils;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;


import ac.liv.comp319.utils.Base64Coder;

public class Encryptor {
	// Simple encryptor/decryptor to keep config files
	// safe
	/* 
	* Hopefully the documentation that you're using can give you some suitable test data to fill in 
	* these constants.
	*/
	private static final String SHARED_KEY = "$�^%XDVDSFDCEDnm5nsddsdfd4344d";
	private static Encryptor instance=null;
	
	public synchronized static final Encryptor  getInstance() {
		if (instance==null) {
			instance=new Encryptor();
		}
		return(instance);
	}
	
	public String encrypt(String plainText) {
		String cipherText="";
		try {
		String algorithm = "DESede";
		String transformation = "DESede/CBC/PKCS5Padding";
		byte[] keyValue = SHARED_KEY.getBytes();
		DESedeKeySpec keySpec = new DESedeKeySpec(keyValue);
		IvParameterSpec iv = new IvParameterSpec(new byte[8]);
		SecretKey key = SecretKeyFactory.getInstance(algorithm).generateSecret(keySpec);
		Cipher encrypter = Cipher.getInstance(transformation);
		encrypter.init(Cipher.ENCRYPT_MODE, key, iv);
		byte[] input = plainText.getBytes("UTF-8");
		byte[] encrypted = encrypter.doFinal(input);
		cipherText=Base64Coder.encodeLines(encrypted);
		} catch (Exception e) {
			Log.ERROR_LOG.write("Problem decoding message");
			Log.ERROR_LOG.write(e);
		}
		return(cipherText);
	}
	
	public String decrypt(String cipherText) {
		String plainText="";
		try {
			String algorithm = "DESede";
			String transformation = "DESede/CBC/PKCS5Padding";
			byte[] keyValue = SHARED_KEY.getBytes();
			System.out.println("Len is "+keyValue.length);
			
			DESedeKeySpec keySpec = new DESedeKeySpec(keyValue);
			/* Initialization Vector of 8 bytes set to zero. */
			IvParameterSpec iv = new IvParameterSpec(new byte[8]);
			SecretKey key = SecretKeyFactory.getInstance(algorithm).generateSecret(keySpec);
			Cipher decrypter = Cipher.getInstance(transformation);
			decrypter.init(Cipher.DECRYPT_MODE, key, iv);
			byte [] secretMess=Base64Coder.decode(cipherText);
			byte[] decrypted = decrypter.doFinal(secretMess);
			plainText=new String(decrypted);
		} catch (Exception e) {
			Log.ERROR_LOG.write("Problem decoding message");
			Log.ERROR_LOG.write(e);
		}
		return(plainText);
	}		
	
	public static void main(String argsv[]) {
		Encryptor instance=new Encryptor();
		try {
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
