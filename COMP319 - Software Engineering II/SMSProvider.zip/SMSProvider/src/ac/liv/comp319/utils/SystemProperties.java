/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.liv.comp319.utils;

import java.util.Hashtable;
import java.util.Enumeration;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;


/**
 *
 * @author Seb
 */
public class SystemProperties {

    private static final String SYSTEM_PROPERTY_FILENAME="sysprop.dat";
    private static SystemProperties instance=null;
    
    /**
     * Single with lazy initialization
     * @return   instance of singleton
     */
    public static synchronized SystemProperties getInstance() {
        if (instance==null) {
            instance=new SystemProperties();
        }
        return(instance);
    }
    
    /**
     * Private constructor for system properties
     */
    private SystemProperties() {
        loadAll();
    }

    /**
     * Hashtable of Java properties
     */
    private Hashtable<String, String> allProperties = new Hashtable<String, String>();

    /**
     * Sets a system property with the given name to the given value
     * @param name   Search key as string
     * @param value
     */
    public void setProperty(String name, String value) {
        allProperties.put(name, value);
        saveAll();  // save to persistant storage
    }

    /**
     * Sets a system property with the given name to the given value
     * @param name   Search key as string
     * @param value
     */
    public void setProperty(String name, int value) {
        allProperties.put(name, "" + value);
        saveAll();  // save to persistant storage
    }

    /**
     * Sets a system property with the given name to the given value
     * @param name   Search key as string
     * @param value
     */
    public void setProperty(String name, long value) {
        allProperties.put(name, "" + value);
        saveAll();  // save to persistant storage
    }
    
    /**
     * 
     * @param name  key
     * @param value  value stored
     */
    public void setProperty(String name, boolean value) {
    	if (value) {
           allProperties.put(name, "true");
    	} else {
    		allProperties.put(name, "false");
    	}
        saveAll();  // save to persistant storage
    }
    
    
    /**
     * Gets a string value of a system property against a name
     * @param name  the name of the property stored
     * @return  the property value or null of no such property stored
     */
    public String getStringProperty(String name) {
        String ret = null;    // if not present return null
        if (this.allProperties.containsKey(name)) {
            ret = allProperties.get(name);
        }
        return (ret);
    }

    /**
     * Gets a int value of a system property against a name
     * @param name  the name of the property stored
     * @return  the property value or 0 if no such property stored
     */
    public int getIntProperty(String name) {
        int ret = 0;
        String values = getStringProperty(name);
        if (values != null) {
            try {
                ret = Integer.parseInt(values);
            } catch (Exception e) {
                Log.ERROR_LOG.write(e);
            }
            ;
        }
        return (ret);
    }

    /**
     * Gets a long value of a system property against a name
     * @param name  the name of the property stored
     * @return  the property value or 0L if no such property stored
     */
    public long getLongProperty(String name) {
        long ret = 0;
        String values = getStringProperty(name);
        if (values != null) {
            try {
                ret = Long.parseLong(values);
            } catch (Exception e) {
                Log.ERROR_LOG.write(e);
            }
            ;
        }
        return (ret);
    }
    
    /**
     * 
     * @param name Name of property
     * @return  true or false depending on property stored
     */
    public boolean getBooleanProperty(String name) {
        boolean ret = false;
        String values = getStringProperty(name);
        if (values != null) {
            try {
            	if (values.equals("true"))
                   ret=true;
            } catch (Exception e) {
                Log.ERROR_LOG.write(e);
            }
            ;
        }
        return (ret);
    }
    

    private void loadAll() {
        try {
            FileReader freader = new FileReader(SYSTEM_PROPERTY_FILENAME);
            BufferedReader br=new BufferedReader(freader);
            String name=null;
            do {
            name=br.readLine();
            String value=br.readLine();
            if ( (name!=null) && (value!=null)) {
                try {
                    allProperties.put(name, value); // load up in hash list
                } catch (Exception e) { };
            }
            } while (name!=null);


        } catch (java.io.FileNotFoundException fnf) {
        	saveAll();	// special case, first time system properties created
        }
        catch (Exception exc) {
            exc.printStackTrace();
            
            Log.ERROR_LOG.write(exc);
        }
        ;
    }

    /**
     * Save all the properties as a CSV file, this code would ideally
     * be replaced by storage in a DBMS to make it more flexible
     */
    private void saveAll() {
        try {
            FileWriter fwriter = new FileWriter(SYSTEM_PROPERTY_FILENAME);
            Enumeration<String> keys = (Enumeration<String>) allProperties.keys();
            while (keys.hasMoreElements()) {
                String name = keys.nextElement();
                String outputs = name + "\n" + allProperties.get(name)+"\n";
                fwriter.write(outputs);
            }
            fwriter.close();
        } catch (Exception exc) {
        	exc.printStackTrace();
            Log.ERROR_LOG.write(exc);
        }
        ;
    }

    private void testIt() {
        //sysProp.setProperty("username", "coopes");
        //sysProp.setProperty("password", "testit");
        //sysProp.setProperty("height", 10);
        //sysProp.setProperty("distance",100L);
        System.out.println("UName is "+getStringProperty("username"));
        System.out.println("UPassword is "+getStringProperty("password"));
        System.out.println("UHeight is "+getIntProperty("height"));
        System.out.println("UDistance is "+getIntProperty("distance"));

    }

    public static void main(String argsv[]) {
        SystemProperties sysProp=getInstance();
        sysProp.testIt();
        

    }
}
