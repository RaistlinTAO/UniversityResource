package ac.liv.comp319.utils;

public interface Nameable {
	public String getName();

}
