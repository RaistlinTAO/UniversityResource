import ac.liv.comp319.sms.SMSProviderManager;
import ac.liv.comp319.sms.TestSMSProvider;
import ac.liv.comp319.utils.SystemProperties;


public class Main {

	/**
	 * @param args
	 */
	
	private void setUpPropertiesForTest() {
		
		SMSProviderManager.getInstance().getProviderList().moveToTop("SMSTEXTLOCAL");
		SystemProperties.getInstance().setProperty("TEXTLOCAL_REQUEST_URL","https://api.txtlocal.com/send/");
		SystemProperties.getInstance().setProperty("TEXTLOCAL_APIKEY","");
	}
	
	private void doTest() {
		this.setUpPropertiesForTest();
		SMSProviderManager.getInstance().getProviderList().moveToTop("TEXTLOCAL");
	//	SMSProviderManager.getInstance().dumpProviders();
		System.out.println("Trying to send message");
		SMSProviderManager.getInstance().sendSMSMessage("Hello World", "545","44","44123"); // send test message
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main instance=new Main();
		instance.doTest();
	}

}
